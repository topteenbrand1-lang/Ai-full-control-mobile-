@echo off
setlocal
cd /d "%~dp0"
echo == 1/3: Offline source verification ==
python verify_project.py
if errorlevel 1 exit /b 1
echo.
echo == 2/3: Check Android build prerequisites ==
where java >nul 2>nul
if errorlevel 1 (echo BLOCKED: Install JDK 17. & exit /b 2)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (echo BLOCKED: Install Android Studio + Android SDK 35 and set ANDROID_HOME or ANDROID_SDK_ROOT. & exit /b 2)
where gradle >nul 2>nul
if errorlevel 1 (echo BLOCKED: Gradle command/wrapper unavailable. Open this project in Android Studio and use Gradle tooling, or install compatible Gradle 8.9+. & exit /b 2)
echo.
echo == 3/3: Unit tests and debug APK build ==
gradle testDebugUnitTest assembleDebug
if errorlevel 1 exit /b 1
echo PASS: APK should be under app\build\outputs\apk\debug\
