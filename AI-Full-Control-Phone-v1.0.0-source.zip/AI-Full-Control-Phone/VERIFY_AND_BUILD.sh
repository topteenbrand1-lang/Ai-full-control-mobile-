#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo '== 1/3: Offline source verification =='
python3 verify_project.py
echo
echo '== 2/3: Check Android build prerequisites =='
if ! command -v java >/dev/null 2>&1; then echo 'BLOCKED: Java/JDK not installed.'; exit 2; fi
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  echo 'BLOCKED: ANDROID_HOME or ANDROID_SDK_ROOT is not set. Install Android Studio + Android SDK 35.'
  echo 'Open this project in Android Studio, wait for Gradle Sync, then run the Gradle tasks below.'
  exit 2
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo 'BLOCKED: Gradle command/wrapper unavailable. Open project in Android Studio and use its Gradle tooling, or install compatible Gradle 8.9+.'
  exit 2
fi
echo
echo '== 3/3: Unit tests and debug APK build =='
gradle testDebugUnitTest assembleDebug
printf '\nPASS: Gradle tests and debug build completed. APK should be under app/build/outputs/apk/debug/.\n'
