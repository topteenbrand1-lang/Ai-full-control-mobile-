# AI Full-Control Phone with Voice — Starter v1.0.0

A runnable Android starter for a Bengali/English voice assistant. This is a safe, user-visible foundation, not a claim of universal or privileged full-phone control.

## Current features
- Text commands and Android speech-recognition activity
- Bengali text-to-speech response (depends on installed TTS voice)
- Device capability detection: Android version, model, RAM estimate, low-RAM flag
- Safe command routing to Settings, Wi-Fi, Bluetooth, Display, Sound, Dialer, Help, and device info
- Unknown commands fail closed; no arbitrary shell, hidden surveillance, or automatic phone calls
- Unit tests for core intent recognition

## Requirements
- Android Studio with Android SDK 35 installed
- JDK 17
- Internet access on first Gradle sync to download Android Gradle Plugin and test dependencies
- Android 8.0 (API 26) or later for the current app configuration

## Build and test
Open this folder in Android Studio, allow Gradle sync, then run:

```bash
./gradlew test
./gradlew assembleDebug
```

This archive does not bundle a Gradle wrapper JAR. If `gradlew` is absent, use Android Studio's Gradle tooling or generate a wrapper using an installed Gradle 8.9+ distribution (`gradle wrapper`).

Install the debug APK on a test phone/emulator and verify microphone permission, voice recognition service, Bengali TTS availability, Settings intents, and behavior with network disabled. Speech recognition may use the device's selected recognition provider and may require network connectivity.

## Architecture
- `AssistantBrain`: deterministic starter intent parser; replace with a tested LLM adapter for open-ended reasoning.
- `ActionEngine`: allow-listed visible Android intents.
- `DeviceCapabilities`: runtime capability and memory profile detection.
- `MainActivity`: UI, speech input, and TTS output.

## Security and platform limits
- Microphone access is permission-gated and only requested after pressing Voice.
- The app does not record continuously, start an always-on wake word, or upload audio itself.
- It does not have root/system privileges. Android restricts many settings and system operations.
- iOS third-party apps cannot obtain unrestricted operating-system control. AOSP system integration requires a separately built and appropriately signed system image.
- Do not put API keys or secrets in source control. A future cloud AI adapter should use a backend, authentication, rate limits, and explicit privacy disclosure.

## Verification status
Source files and test cases have been generated. No Android build, emulator run, or physical-device test is claimed from this environment unless a later report explicitly records the command and result. Treat release readiness as **NOT VERIFIED** until build and device checks pass.
