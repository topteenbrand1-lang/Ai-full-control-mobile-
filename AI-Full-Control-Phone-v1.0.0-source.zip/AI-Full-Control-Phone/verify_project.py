#!/usr/bin/env python3
"""Fast offline sanity checks for AI Full-Control Phone starter project."""
from pathlib import Path
import subprocess, sys, xml.etree.ElementTree as ET, zipfile
ROOT = Path(__file__).resolve().parent
checks = []
def report(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
    print(f"{'PASS' if ok else 'FAIL'} | {name}" + (f" — {detail}" if detail else ''))

required = [
 'settings.gradle.kts','build.gradle.kts','gradle.properties',
 'app/build.gradle.kts','app/src/main/AndroidManifest.xml',
 'app/src/main/java/com/aifcp/assistant/MainActivity.kt',
 'app/src/main/java/com/aifcp/assistant/AssistantBrain.kt',
 'app/src/main/java/com/aifcp/assistant/ActionEngine.kt',
 'app/src/main/java/com/aifcp/assistant/DeviceCapabilities.kt',
 'app/src/test/java/com/aifcp/assistant/AssistantBrainTest.kt',
]
missing = [p for p in required if not (ROOT/p).is_file()]
report('Required project files', not missing, ', '.join(missing) if missing else f'{len(required)} files found')
try:
    ET.parse(ROOT/'app/src/main/AndroidManifest.xml')
    report('Android Manifest XML', True, 'well-formed XML')
except Exception as e:
    report('Android Manifest XML', False, str(e))

main = (ROOT/'app/src/main/java/com/aifcp/assistant/MainActivity.kt').read_text(encoding='utf-8')
report('Multiline device-info string', '"""ডিভাইস:' in main, 'Kotlin raw string used for multiline text')
report('Microphone permission declared', 'android.permission.RECORD_AUDIO' in (ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8'))
report('Unknown commands fail closed', 'Unknown' in (ROOT/'app/src/main/java/com/aifcp/assistant/AssistantBrain.kt').read_text(encoding='utf-8'))

kotlinc = subprocess.run(['bash','-lc','command -v kotlinc'], capture_output=True, text=True).stdout.strip()
if kotlinc:
    out = ROOT/'.verify-assistant-brain.jar'
    src = ROOT/'app/src/main/java/com/aifcp/assistant/AssistantBrain.kt'
    r = subprocess.run([kotlinc, str(src), '-d', str(out)], capture_output=True, text=True)
    report('Standalone AssistantBrain Kotlin compile', r.returncode == 0, (r.stderr.strip()[-400:] if r.returncode else 'compiled successfully'))
    if out.exists(): out.unlink()
else:
    report('Standalone AssistantBrain Kotlin compile', False, 'kotlinc not installed; skipped')

print('\nSummary: %d/%d checks passed.' % (sum(ok for _,ok,_ in checks), len(checks)))
print('NOTE: These are offline sanity checks, not a full Android Gradle build or device test.')
sys.exit(0 if all(ok for _,ok,_ in checks) else 1)
