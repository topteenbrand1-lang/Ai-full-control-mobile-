package com.aifcp.assistant

import android.content.Context
import android.os.Build
import android.app.ActivityManager

/** Reports capabilities visible to an ordinary Android application; not privileged system access. */
data class DeviceCapabilities(
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val totalRamMb: Long,
    val lowRamDevice: Boolean
) {
    companion object {
        fun detect(context: Context): DeviceCapabilities {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memory = ActivityManager.MemoryInfo()
            manager.getMemoryInfo(memory)
            return DeviceCapabilities(
                manufacturer = Build.MANUFACTURER.orEmpty(),
                model = Build.MODEL.orEmpty(),
                androidRelease = Build.VERSION.RELEASE.orEmpty(),
                sdkInt = Build.VERSION.SDK_INT,
                totalRamMb = memory.totalMem / (1024L * 1024L),
                lowRamDevice = manager.isLowRamDevice
            )
        }
    }

    fun profile(): String = when {
        lowRamDevice || totalRamMb < 5_000 -> "LITE"
        totalRamMb < 9_000 -> "STANDARD"
        totalRamMb < 17_000 -> "ADVANCED"
        else -> "HIGH_CAPACITY"
    }
}
