package com.aifcp.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val brain = AssistantBrain()
    private lateinit var actions: ActionEngine
    private val requestSpeech = 1001
    private val requestAudioPermission = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actions = ActionEngine(this)
        tts = TextToSpeech(this, this)
        buildUi()
        val caps = DeviceCapabilities.detect(this)
        status.text = "Ready • Android ${caps.androidRelease} • ${caps.profile()} profile"
        output.text = "স্বাগতম! নিচে লিখুন অথবা Voice বোতাম চাপুন। প্রথম সংস্করণে সমর্থিত কাজ সীমিত।"
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        val title = TextView(this).apply {
            text = "AI Phone Assistant"
            textSize = 26f
            setTextColor(0xFF172554.toInt())
        }
        status = TextView(this).apply { textSize = 13f; setPadding(0, 8, 0, 18) }
        input = EditText(this).apply {
            hint = "যেমন: Wi‑Fi সেটিংস খোলো"
            textSize = 16f
            minHeight = 56
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val run = Button(this).apply { text = "Run command"; setOnClickListener { handleCommand(input.text.toString()) } }
        val voice = Button(this).apply { text = "🎙 Voice"; setOnClickListener { startVoiceInput() } }
        buttons.addView(run, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(voice, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        output = TextView(this).apply {
            textSize = 17f
            setTextColor(0xFF111827.toInt())
            setPadding(0, 20, 0, 16)
        }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(title)
        root.addView(status)
        root.addView(input)
        root.addView(buttons)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun handleCommand(text: String) {
        if (text.isBlank()) {
            showResult("আগে একটি নির্দেশ লিখুন বা Voice বোতাম চাপুন।")
            return
        }
        val intent = brain.understand(text)
        val result = when (intent) {
            AssistantIntent.Help -> brain.helpText()
            AssistantIntent.ShowDeviceInfo -> {
                val c = DeviceCapabilities.detect(this)
                """ডিভাইস: ${c.manufacturer} ${c.model}
Android: ${c.androidRelease} (API ${c.sdkInt})
RAM: প্রায় ${c.totalRamMb} MB
Profile: ${c.profile()}
Low-RAM device: ${c.lowRamDevice}"""
            }
            else -> actions.execute(intent)
        }
        showResult(result)
    }

    private fun showResult(message: String) {
        output.text = message
        if (::tts.isInitialized && message.isNotBlank()) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "assistant-response")
    }

    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showResult("এই ডিভাইসে speech recognition service পাওয়া যায়নি। আপাতত লিখে নির্দেশ দিন।")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudioPermission)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "আপনার নির্দেশ বলুন")
        }
        try { startActivityForResult(intent, requestSpeech) }
        catch (_: Exception) { showResult("Voice input চালু করা যায়নি। লিখে চেষ্টা করুন।") }
    }

    @Deprecated("Uses activity result API compatibility for broad Android support")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(spoken)
            handleCommand(spoken)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudioPermission && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startVoiceInput()
        else if (requestCode == requestAudioPermission) showResult("মাইক্রোফোন অনুমতি ছাড়া voice input চালু হবে না। লিখে নির্দেশ দিতে পারেন।")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("bn", "BD")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
