package com.aifcp.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Executes only explicitly supported, user-visible Android actions. */
class ActionEngine(private val context: Context) {
    fun execute(intent: AssistantIntent): String = try {
        when (intent) {
            AssistantIntent.OpenSettings -> launch(Settings.ACTION_SETTINGS, "সেটিংস খুলেছি।")
            AssistantIntent.OpenWifiSettings -> launch(Settings.ACTION_WIFI_SETTINGS, "Wi‑Fi সেটিংস খুলেছি।")
            AssistantIntent.OpenBluetoothSettings -> launch(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth সেটিংস খুলেছি।")
            AssistantIntent.OpenDisplaySettings -> launch(Settings.ACTION_DISPLAY_SETTINGS, "ডিসপ্লে সেটিংস খুলেছি।")
            AssistantIntent.OpenSoundSettings -> launch(Settings.ACTION_SOUND_SETTINGS, "সাউন্ড সেটিংস খুলেছি।")
            AssistantIntent.OpenDialer -> {
                val dial = Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(dial)
                "ডায়ালার খুলেছি। কল করার আগে নম্বর ও কল নিজে নিশ্চিত করুন।"
            }
            AssistantIntent.ShowDeviceInfo -> "DEVICE_INFO"
            AssistantIntent.Help -> "HELP"
            is AssistantIntent.Unknown -> "এই নির্দেশটি এখনও সমর্থিত নয়। ‘সাহায্য’ বললে সমর্থিত কাজগুলো জানাব।"
        }
    } catch (_: ActivityNotFoundException) {
        "এই ডিভাইসে সংশ্লিষ্ট সেটিংস স্ক্রিন খোলা যায়নি।"
    } catch (e: SecurityException) {
        "Android নিরাপত্তা নীতির কারণে কাজটি অনুমোদিত হয়নি।"
    } catch (_: Exception) {
        "কাজটি সম্পন্ন করা যায়নি। আবার চেষ্টা করুন।"
    }

    private fun launch(action: String, success: String): String {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return success
    }
}
