package com.aifcp.assistant

/** Safe deterministic starter brain. Replace/extend with a remote or on-device model adapter. */
sealed interface AssistantIntent {
    data object OpenSettings : AssistantIntent
    data object OpenWifiSettings : AssistantIntent
    data object OpenBluetoothSettings : AssistantIntent
    data object OpenDisplaySettings : AssistantIntent
    data object OpenSoundSettings : AssistantIntent
    data object OpenDialer : AssistantIntent
    data object ShowDeviceInfo : AssistantIntent
    data object Help : AssistantIntent
    data class Unknown(val originalText: String) : AssistantIntent
}

class AssistantBrain {
    fun understand(text: String): AssistantIntent {
        val q = text.trim().lowercase()
        if (q.isBlank()) return AssistantIntent.Unknown(text)
        return when {
            listOf("help", "সাহায্য", "কি করতে পারো", "কী করতে পারো").any(q::contains) -> AssistantIntent.Help
            listOf("device info", "phone info", "ডিভাইসের তথ্য", "ফোনের তথ্য", "র‍্যাম", "ram").any(q::contains) -> AssistantIntent.ShowDeviceInfo
            listOf("wifi", "wi-fi", "ওয়াইফাই", "ওয়াইফাই").any(q::contains) -> AssistantIntent.OpenWifiSettings
            listOf("bluetooth", "ব্লুটুথ").any(q::contains) -> AssistantIntent.OpenBluetoothSettings
            listOf("display", "brightness settings", "ডিসপ্লে", "উজ্জ্বলতা সেটিংস").any(q::contains) -> AssistantIntent.OpenDisplaySettings
            listOf("sound settings", "volume settings", "সাউন্ড সেটিংস", "শব্দ সেটিংস").any(q::contains) -> AssistantIntent.OpenSoundSettings
            listOf("dialer", "phone app", "ডায়ালার", "ডায়ালার", "ফোন অ্যাপ").any(q::contains) -> AssistantIntent.OpenDialer
            listOf("settings", "open settings", "সেটিংস", "সেটিং খুল").any(q::contains) -> AssistantIntent.OpenSettings
            else -> AssistantIntent.Unknown(text)
        }
    }

    fun helpText(): String = "আমি এখন সেটিংস, Wi‑Fi/Bluetooth সেটিংস, ডিসপ্লে/সাউন্ড সেটিংস, ডায়ালার এবং ডিভাইসের তথ্য খুলতে পারি। আরও কাজ যোগ করা হবে।"
}
