package com.aifcp.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AssistantBrainTest {
    private val brain = AssistantBrain()

    @Test fun recognizesWifiSettingsInEnglish() {
        assertEquals(AssistantIntent.OpenWifiSettings, brain.understand("open wifi settings"))
    }

    @Test fun recognizesHelpInBangla() {
        assertEquals(AssistantIntent.Help, brain.understand("সাহায্য"))
    }

    @Test fun unknownCommandsDoNotBecomeActions() {
        assertTrue(brain.understand("do something unrestricted") is AssistantIntent.Unknown)
    }

    @Test fun recognizesDeviceInfo() {
        assertEquals(AssistantIntent.ShowDeviceInfo, brain.understand("ফোনের তথ্য দেখাও"))
    }
}
