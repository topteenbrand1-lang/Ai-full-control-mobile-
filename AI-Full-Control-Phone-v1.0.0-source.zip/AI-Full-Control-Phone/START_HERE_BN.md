# দ্রুত শুরু (বাংলা)

## সবচেয়ে সহজ উপায়: Android Studio
1. কম্পিউটারে Android Studio এবং JDK 17 ইনস্টল করুন।
2. Android Studio খুলে **Open** চাপুন। ZIP Extract করে `AI-Full-Control-Phone` ফোল্ডার নির্বাচন করুন।
3. SDK Manager থেকে **Android SDK Platform 35** এবং Build Tools ইনস্টল করুন।
4. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন। ইন্টারনেট লাগতে পারে।
5. **Build > Make Project** চালান। তারপর **Run** চাপুন বা একটি Android Emulator নির্বাচন করুন।
6. টেস্ট: Terminal-এ `gradle testDebugUnitTest` (বা Android Studio-এর Gradle panel থেকে `testDebugUnitTest`) চালান।
7. APK: `app/build/outputs/apk/debug/app-debug.apk`।

## এক-ক্লিক sanity check
- Windows: `VERIFY_AND_BUILD.bat` ডাবল-ক্লিক করুন।
- macOS/Linux: Terminal-এ `./VERIFY_AND_BUILD.sh` চালান।

স্ক্রিপ্ট প্রথমে অফলাইন সোর্স পরীক্ষা করবে। Android SDK/Gradle প্রস্তুত না থাকলে স্পষ্টভাবে BLOCKED দেখাবে; সেটিকে PASS হিসেবে দেখাবে না।

## গুরুত্বপূর্ণ
- Android Studio-এর **Open** দিয়ে প্রজেক্ট ফোল্ডার খুলতে হবে, ZIP ফাইল সরাসরি নয়।
- Voice ব্যবহারে মাইক্রোফোন অনুমতি দিন। Speech Recognition/TTS ডিভাইস ও ভাষা-প্যাকের ওপর নির্ভরশীল।
- প্রথম সংস্করণে সীমিত, দৃশ্যমান Android actions আছে; এটি সব ফোনের পূর্ণ নিয়ন্ত্রণ নয় এবং এখনো পূর্ণ Generative AI Brain নয়।
- বাস্তব ফোনে ইনস্টল করার আগে নিজের ডিভাইসে পরীক্ষা করুন।
